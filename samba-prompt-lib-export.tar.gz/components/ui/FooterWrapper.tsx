import Footer from './Footer';

export default function FooterWrapper() {
  return <Footer />;
} 