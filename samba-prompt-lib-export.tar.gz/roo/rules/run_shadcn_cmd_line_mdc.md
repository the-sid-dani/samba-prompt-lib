---
description: use this for latest usage of shadcn
globs:
---
# When using shadcn or run shadcn related CLI:
- use`npx shadcn@latest install xxx`, do NOT use shadcn ui, it is outdated
